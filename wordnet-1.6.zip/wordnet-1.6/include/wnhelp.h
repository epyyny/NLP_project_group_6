/*

  wnhelp.h

*/

extern char **helptext[NUMPARTS + 1];
